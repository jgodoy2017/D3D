#!/bin/bash

TYPE=Release
CURRENT_DIR=`pwd`

echo -n "Descomprimiendo DCMTK... "
gunzip dcmtk-3.6.2.tar.gz
tar xf dcmtk-3.6.2.tar
echo "[ OK ]"

echo -n "Descomprimiendo D3D...   "
gunzip dcmtk_d3d.tar.gz
tar xf dcmtk_d3d.tar -C dcmtk-3.6.2/ --overwrite
echo "[ OK ]"

echo "Compilando todo..."
mkdir -p dcmtk-3.6.2/build-$TYPE
cd dcmtk-3.6.2/build-$TYPE/
cmake .. -DCMAKE_BUILD_TYPE=$TYPE -DDCMTK_WIDE_CHAR_FILE_IO_FUNCTIONS=1 -DDCMTK_WITH_TIFF=OFF -DDCMTK_WITH_PNG=OFF -DDCMTK_WITH_OPENSSL=OFF -DDCMTK_WITH_XML=OFF -DDCMTK_WITH_ZLIB=ON -DDCMTK_WITH_SNDFILE=OFF -DDCMTK_WITH_ICONV=ON -DDCMTK_WITH_WRAP=OFF -DCMAKE_INSTALL_PREFIX=${CURRENT_DIR}/dcmtk-3.6.2/$TYPE
make -j8 install

cd ${CURRENT_DIR}

